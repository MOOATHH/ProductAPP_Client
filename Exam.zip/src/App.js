import React, { Component } from "react";

class User extends Component {
  state = {
    newUser: { firstName: "", lastName: "" }
  };
  handleFirstName(e) {
    let value = e.target.value;
    this.setState(prevState => ({
      newUser: {
        ...prevState.newUser,
        firstName: value
      }
    }));
  }
  handleCounty(e) {
    let value = e.target.value;
    this.setState(prevState => ({
      newUser: {
        ...prevState.newUser,
        County: value
      }
    }));
  }

  getFullName() {
    return this.state.newUser.firstName + " " + this.state.newUser.lastName;
  }

  render() {
    return (
      <div>
        Full Name:
        <input
          type="text"
          onChange={this.handleFirstName.bind(this)}
          placeholder="Enter Full Name"
        />
        <br />
        County:
        <input
          type="text"
          onChange={this.handleCounty.bind(this)}
          placeholder="Enter last Name"
        />
        <br />
        Email:
        <input
          type="text"
          onChange={this.handleCounty.bind(this)}
          placeholder="Enter last Name"
        />
        <br />
        Passwrd:
        <input
          type="password"
          onChange={this.handleCounty.bind(this)}
          placeholder="Enter last Name"
        />
        <br />
        Conform Password:
        <input
          type="password"
          onChange={this.handleCounty.bind(this)}
          placeholder="Enter last Name"
        />
        <br />
        <input type="submit" />
        <input type="Reset" />
        {/* FullName: {this.getFullName()} */}
      </div>
    );
  }
}
export default User;
